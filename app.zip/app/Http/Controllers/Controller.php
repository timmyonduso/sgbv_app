<?php

namespace App\Http\Controllers;

use Essa\APIToolKit\Api\ApiResponse;

abstract class Controller
{
    use ApiResponse;
}
