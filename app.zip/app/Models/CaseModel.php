<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class CaseModel extends Model
{
    use SoftDeletes;

    // Explicitly set table name to avoid reserved keyword issues
    protected $table = 'cases';

    protected $fillable = [
        'incident_id',
        'assigned_to',
        'status_id',
        'resolution_notes'
    ];

    // Relationships
    public function incident(): BelongsTo
    {
        return $this->belongsTo(Incident::class);
    }

    public function assignedTo(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function status(): BelongsTo
    {
        return $this->belongsTo(Status::class);
    }

    public function updates(): HasMany
    {
        return $this->hasMany(CaseUpdate::class, 'case_id');
    }

    // Scopes
    public function scopeOpen($query)
    {
        return $query->whereHas('status', function($q) {
            $q->where('name', 'Open');
        });
    }

    public function scopeClosed($query)
    {
        return $query->whereHas('status', function($q) {
            $q->where('name', 'Closed');
        });
    }

    // Helpers
    public function isAssignedTo(User $user): bool
    {
        return $this->assigned_to === $user->id;
    }
}
