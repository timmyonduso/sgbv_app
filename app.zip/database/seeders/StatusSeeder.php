<?php

namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class StatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $now = Carbon::now();

        $statuses = [
            // Incident Statuses
            ['name' => 'Pending', 'created_at' => $now, 'updated_at' => $now],
            ['name' => 'Assigned', 'created_at' => $now, 'updated_at' => $now],
            ['name' => 'Resolved', 'created_at' => $now, 'updated_at' => $now],

            // Case Statuses
            ['name' => 'Open', 'created_at' => $now, 'updated_at' => $now],
            ['name' => 'In Progress', 'created_at' => $now, 'updated_at' => $now],
            ['name' => 'Closed', 'created_at' => $now, 'updated_at' => $now],
        ];

        DB::table('statuses')->insert($statuses);
    }
}
