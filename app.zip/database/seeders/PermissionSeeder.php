<?php

namespace Database\Seeders;

use App\Models\Permission;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $actions = [
            'viewAny',  // View all resources (admin only)
            'view',     // View specific resources
            'create',   // Create new resources
            'update',   // Edit existing resources
            'delete',   // Soft delete resources
            'restore',  // Restore deleted resources
            'forceDelete', // Permanently delete resources (admin only)
        ];

        $resources = [
            'admin',
            'user',
            'survivor',        // GBV Survivors
            'case',            // GBV Case Management
            'report',          // Incident Reports
            'support_service', // Medical & Psychological Support
            'legal_aid',       // Legal & Justice Support
            'shelter',         // Safe Houses & Temporary Shelter
            'hotline',         // Emergency GBV Hotline Calls
            'counseling',      // Counseling & Mental Health Support
            'awareness',       // GBV Awareness Campaigns
            'perpetrator',     // Perpetrator Tracking
            'referral',        // Referral Systems & Coordination
            'feedback',        // Feedback & Improvement
        ];

        collect($resources)
            ->crossJoin($actions)
            ->map(fn ($set) => implode('_', $set))
            ->each(fn ($permission) => Permission::create(['name' => $permission]));
    }
}
